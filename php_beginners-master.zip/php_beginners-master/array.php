<?php
/*
An array in PHP is a data structure that can store multiple values in a single variable. Arrays are useful for organizing data into a structured format, allowing you to easily access and manipulate the data.

*/ 

$fruits = array( "apple", "banana", "cherry" );

$numbers=array(1,2,20,50);
print_r($fruits);
