<?php

$numbers = array( 8, 23, 15, 42, 16, 4 );
// print_r($numbers);
// echo PHP_EOL;
// ===========

// var_dump($numbers);
// echo PHP_EOL;

// =========

// echo count( $numbers );
// echo PHP_EOL;

// =========

// echo max( $numbers );
// echo PHP_EOL;

// =========

// echo min( $numbers );
// echo PHP_EOL;

// =========

// sort( $numbers );
// print_r($numbers);
// echo PHP_EOL;

// =========


// rsort( $numbers );
// print_r($numbers);
// echo PHP_EOL;

// =========

// print_r( $numbers );
// echo PHP_EOL;
// =========

// echo $num_string = implode( ",", $numbers );

// echo PHP_EOL;
// =========
// print_r( explode( ",", $num_string ) );
// echo PHP_EOL;
// =========

// echo in_array( 15, $numbers ); // returns T/F
// echo PHP_EOL;
// =========
// echo in_array( 19, $numbers ); // returns T/F