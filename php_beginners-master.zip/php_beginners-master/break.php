<?php

// for ( $count = 0; $count <= 10; $count++ ) {
//     if ( $count == 5 ) {
//         break;
//     }
//     echo $count . ", ";
// }


echo PHP_EOL;
 // loop inside a loop with break

// for ( $i = 0; $i <= 5; $i++ ) {
//     // if ( $i % 2 == 0 ) {continue ( 1 );}
//     if ( $i == 3 ) {continue ( 1 );}
//     for ( $k = 0; $k <= 5; $k++ ) {
//         if ( $k == 3 ) {break ( 2 );}
//         echo $i . "-" . $k .PHP_EOL;
//     }
// }

