<?php
/*

Date/Time and Function Joke:
============================
Why did the PHP programmer break up with his girlfriend?

Because she didn't understand his strtotime() function and was always asking him to add or subtract hours from their dates!

*/ 