<?php

/*
Agenda: Operators:
===================
PHP divides the operators in the following groups:

Arithmetic operators
Assignment operators
Comparison operators
Increment/Decrement operators
Logical operators
String operators
Array operators
Conditional assignment operators

Operators Precedence :
======================
*/ 


// $now = 2023;
//  $ageKarim = $now - 1991;
// $ageRahim = $now - 2018;

// echo $ageKarim;
// echo "\n";
// echo $ageRahim;
// echo "\n";




$x;
$y;
$x = $y = 25 - 10 - 5; // x = y = 10, x = 10
echo "\n";
echo($x." ". $y);
echo "\n";



// $averageAge = $ageKarim + $ageRahim / 2;
// echo $averageAge;
// echo "\n";

// $averageAge = ($ageKarim + $ageRahim) / 2;
// echo $averageAge;
//  echo "\n";

// $age1 = 12;  
// $age2 = 50;

// echo $age1 + $age2;

