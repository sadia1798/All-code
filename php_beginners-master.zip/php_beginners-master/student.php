<?php
$fname="Rabbil";
$mname="Hassan";
$lname="Rupom";
printf('My teacher\'s name is %3$s %1$s %2$s',$fname,$mname,$lname);